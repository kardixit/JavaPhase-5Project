package com.sportyshoes.exceptions;

public class ResourceNotFound extends Exception {

    public ResourceNotFound(String exMsg) {
        super(exMsg);
    }
}
